#include "stdio.h"
#include "stdlib.h"
//int main1();
void printccc();
void printddd();
int main(){
	printf("test");
	printccc();
	printddd();
}
